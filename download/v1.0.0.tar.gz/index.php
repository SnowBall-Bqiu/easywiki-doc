<?php
require_once('WxqqJump/WxqqJump.php');

// 在这里可以调用 WxqqJump.php 里的函数或类，例如：
// $jump = new WxqqJump();
// echo $jump->jump();

?>
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="icon" href="favicon.ico" type="image/x-icon">
    <title>简单WIKI</title>
    <script src="https://cdn.jsdelivr.net/npm/marked/marked.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/dompurify@latest/dist/purify.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap&_cacheOverride=1744614634958" rel="stylesheet">
    <link href="css/wiki.css" rel="stylesheet">
    <script src="js/app.js"></script>
</head>
<body class="bg-gray-50">

    <div id="backdrop" class="fixed inset-0 bg-black bg-opacity-30 backdrop-blur-sm z-40 hidden transition-opacity duration-300"></div>


    <button id="menu-trigger" class="fixed top-4 left-4 z-50 p-3 bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-full shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300 md:hidden">
        <svg class="w-5 h-5 transform transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
            <path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/>
        </svg>
    </button>


    <button id="toc-trigger" class="fixed top-4 right-4 z-50 p-3 bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-full shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300 md:hidden">
        <svg class="w-5 h-5 transform transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
            <path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7"/>
        </svg>
    </button>

    <div class="flex h-screen">

        <nav id="sidebar" class="w-64 bg-white border-r border-gray-200 overflow-y-auto h-full p-4 shadow-lg">
            <div class="flex justify-between items-center mb-4">
                <h2 class="text-lg font-semibold text-gray-900">简单WIKI</h2>
                <button id="menu-toggle" class="p-2 bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-full shadow-md hover:shadow-xl transform hover:scale-105 transition-all duration-300 md:hidden">
                    <svg class="w-5 h-5 transform transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7"/>
                    </svg>
                </button>
            </div>
            <div id="sidebar-content" class="space-y-1"></div>
        </nav>
        <main id="content" class="flex-1 p-8 overflow-y-auto transition-all duration-300"></main>
        <aside id="toc" class="w-64 bg-white border-l border-gray-200 p-4 overflow-y-auto h-full shadow-lg">
            <div class="flex justify-between items-center mb-4">
                <h2 class="text-lg font-semibold text-gray-900">目录</h2>
                <button id="toc-toggle" class="p-2 bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-full shadow-md hover:shadow-xl transform hover:scale-105 transition-all duration-300 md:hidden">
                    <svg class="w-5 h-5 transform transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7"/>
                    </svg>
                </button>
            </div>
            <div id="toc-content" class="space-y-1"></div>
        </aside>
    </div>
</body>
</html>
